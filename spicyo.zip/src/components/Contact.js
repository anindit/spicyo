import { Component } from 'react';


class Contact extends Component {
  componentDidMount() {
    window.scrollTo(0, 0);
  }
  render()
  {
    return (
      null
    );

  } 

}

export default Contact;
