export { default as img } from './images/img.jpg';
export { default as logo1 } from './images/logo1.jpg';

export { default as burger_slide } from './images/burger_slide.png';

export { default as rs1 } from './images/rs1.png';
export { default as rs2 } from './images/rs2.png';
export { default as rs3 } from './images/rs3.png';
export { default as rs4 } from './images/rs4.png';
export { default as rs5 } from './images/rs5.png';
export { default as title } from './images/title.png';
export { default as aboutimg } from './images/about-img.jpg';
export { default as blog_img1 } from './images/blog_img1.png';
export { default as blog_img2 } from './images/blog_img2.png';
export { default as blog_img3 } from './images/blog_img3.png';
export { default as client } from './images/client.jpg';
export { default as client_icon } from './images/client_icon.png';



